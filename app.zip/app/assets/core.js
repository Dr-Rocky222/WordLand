(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./fsrs.js'));else root.WordCore=factory(root.FSRS);})(typeof globalThis!=='undefined'?globalThis:this,function(F){
  'use strict';
  const VERSION=1;
  const settingsDefault={dailyNew:20,retention:0.9,autoAudio:false,speed:1,deck:'all'};
  const scheduler=retention=>F.fsrs({request_retention:retention,enable_fuzz:false,maximum_interval:3650});
  function dayKey(date=new Date()){const d=new Date(date);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
  function fresh(){return {version:VERSION,settings:{...settingsDefault},cards:{},reviews:[],favorites:[],created:new Date().toISOString()};}
  function validDate(x){return typeof x==='string'&&Number.isFinite(Date.parse(x));}
  function hydrate(c){return {...c,due:new Date(c.due),last_review:c.last_review?new Date(c.last_review):undefined};}
  function snapshot(c){return {...c,due:new Date(c.due).toISOString(),last_review:c.last_review?new Date(c.last_review).toISOString():undefined};}
  function validate(s,known){
    if(!s||s.version!==VERSION||!s.settings||!s.cards||Array.isArray(s.cards)||!Array.isArray(s.reviews)||!Array.isArray(s.favorites))throw Error('不是有效的词屿备份文件');
    const t=s.settings;
    if(!Number.isInteger(t.dailyNew)||t.dailyNew<0||t.dailyNew>100||![0.85,0.9,0.95].includes(t.retention)||![0.8,1,1.2].includes(t.speed)||typeof t.autoAudio!=='boolean'||!['all','ielts','starter'].includes(t.deck))throw Error('学习设置无效');
    if(Object.keys(s.cards).length>10000||s.reviews.length>200000||s.favorites.length>10000)throw Error('备份超过支持的大小');
    const isId=id=>typeof id==='string'&&/^v\d{5}$/.test(id)&&(!known||known.has(id));
    for(const [id,c] of Object.entries(s.cards)){
      if(!isId(id)||!c||!validDate(c.due)||!validDate(c.last_review)||!validDate(c.firstSeen)||!Number.isFinite(c.stability)||c.stability<=0||!Number.isFinite(c.difficulty)||c.difficulty<1||c.difficulty>10||![1,2,3].includes(c.state))throw Error('单词记忆数据无效');
      for(const k of ['reps','lapses','elapsed_days','scheduled_days','learning_steps'])if(!Number.isInteger(c[k])||c[k]<0||c[k]>10000000)throw Error('记忆计数无效');
    }
    for(const r of s.reviews){if(!r||!isId(r.id)||!validDate(r.at)||![1,2,3,4].includes(r.rating)||typeof r.isNew!=='boolean')throw Error('复习历史无效');}
    if(!s.favorites.every(isId))throw Error('收藏词条无效');
    return s;
  }
  function todayStats(s,now=new Date()){
    const day=dayKey(now), logs=s.reviews.filter(r=>dayKey(r.at)===day), reviews=logs.filter(r=>!r.isNew);
    return {newCount:logs.filter(r=>r.isNew).length,answers:logs.length,reviewCount:reviews.length,correct:reviews.filter(r=>r.rating>1).length};
  }
  function inDeck(word,deck){return deck==='all'||(deck==='ielts'?word.ielts:word.starter);}
  function queue(s,words,now=new Date()){
    const timestamp=+now, eligible=words.filter(w=>inDeck(w,s.settings.deck));
    // All previously learned cards remain due even after the new-word deck changes.
    const due=words.filter(w=>s.cards[w.id]&&Date.parse(s.cards[w.id].due)<=timestamp).sort((a,b)=>Date.parse(s.cards[a.id].due)-Date.parse(s.cards[b.id].due));
    const remaining=Math.max(0,s.settings.dailyNew-todayStats(s,now).newCount);
    const news=eligible.filter(w=>!s.cards[w.id]).slice(0,remaining);
    return {due,news,next:due[0]||news[0]||null};
  }
  function preview(s,id,now=new Date()){
    const c=s.cards[id]?hydrate(s.cards[id]):F.createEmptyCard(now);
    return scheduler(s.settings.retention).repeat(c,now);
  }
  function answer(s,id,rating,now=new Date()){
    if(![1,2,3,4].includes(rating))throw Error('无效评分');
    const old=s.cards[id], c=old?hydrate(old):F.createEmptyCard(now), result=scheduler(s.settings.retention).next(c,now,rating);
    const card={...snapshot(result.card),firstSeen:old?old.firstSeen:now.toISOString()};
    const review={id,at:now.toISOString(),rating,isNew:!old,day:dayKey(now),log:result.log};
    return {state:{...s,cards:{...s.cards,[id]:card},reviews:[...s.reviews,review]},undo:{id,old:old||null,reviewIndex:s.reviews.length}};
  }
  function undo(s,u){
    if(!u||u.reviewIndex!==s.reviews.length-1)throw Error('无法撤销这次操作');
    const cards={...s.cards};if(u.old)cards[u.id]=u.old;else delete cards[u.id];
    return {...s,cards,reviews:s.reviews.slice(0,-1)};
  }
  function interval(due,now=new Date()){
    const mins=Math.max(1,Math.round((+new Date(due)-+now)/60000));
    if(mins<60)return mins+' 分钟';if(mins<1440)return Math.round(mins/60)+' 小时';const days=Math.round(mins/1440);if(days<30)return days+' 天';if(days<365)return Math.round(days/30)+' 个月';return (days/365).toFixed(1)+' 年';
  }
  return {VERSION,fresh,validate,dayKey,todayStats,queue,preview,answer,undo,interval,inDeck};
});
