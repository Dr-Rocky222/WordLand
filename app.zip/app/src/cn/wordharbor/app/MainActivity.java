package cn.wordharbor.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.media.*;
import android.net.Uri;
import android.speech.tts.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private static final String ORIGIN="https://app.wordharbor.local/";
    private WebView web;
    private SQLiteDatabase db;
    private MediaPlayer player;
    private TextToSpeech tts;
    private boolean ttsReady=false;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Map<String,File> audio=new ConcurrentHashMap<>();
    private final Set<String> builtIn=Collections.synchronizedSet(new HashSet<>());
    private final Set<String> allowedAudio=new HashSet<>();
    private volatile boolean importing=false;
    private String pendingExport;

    @Override public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        db=openOrCreateDatabase("wordharbor.db",MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
        try {
            JSONArray words=new JSONObject(read(getAssets().open("vocab.json"),12000000)).getJSONArray("words");
            for(int i=0;i<words.length();i++){String id=words.getJSONObject(i).getString("id");allowedAudio.add(id+"_w.mp3");allowedAudio.add(id+"_s.mp3");}
            String[] list=getAssets().list("audio");if(list!=null)builtIn.addAll(Arrays.asList(list));
        }catch(Exception e){new AlertDialog.Builder(this).setMessage("词库加载失败，请重新安装完整安装包。").setPositiveButton("关闭",(d,w)->finish()).show();return;}
        scanAudio();
        LinearLayout outer=new LinearLayout(this);outer.setBackgroundColor(Color.rgb(248,248,242));outer.setOrientation(LinearLayout.VERTICAL);
        web=new WebView(this);outer.addView(web,new LinearLayout.LayoutParams(-1,-1));setContentView(outer);
        // Android 15 edge-to-edge: retain native system insets, including keyboard.
        outer.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets i=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.ime());v.setPadding(i.left,i.top,i.right,i.bottom);}
            else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        web.setBackgroundColor(Color.rgb(248,248,242));
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setSupportMultipleWindows(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return true;}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                Uri u=request.getUrl();
                if(!"https".equals(u.getScheme())||!"app.wordharbor.local".equals(u.getHost()))return denied();
                String path=u.getPath();if(path==null||path.contains("..")||path.contains("\\"))return denied();
                path=path.substring(1);if(path.isEmpty())path="index.html";
                try{
                    String mime=path.endsWith(".html")?"text/html":path.endsWith(".css")?"text/css":path.endsWith(".js")?"application/javascript":path.endsWith(".json")?"application/json":path.endsWith(".mp3")?"audio/mpeg":"text/plain";
                    return new WebResourceResponse(mime,"UTF-8",getAssets().open(path));
                }catch(Exception e){return denied();}
            }
        });
        web.addJavascriptInterface(new Bridge(),"Native");
        web.loadUrl(ORIGIN+"index.html");
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,()->goBack());
        tts=new TextToSpeech(this,status->{
            if(status!=TextToSpeech.SUCCESS)return;
            Set<Voice> voices=tts.getVoices();if(voices==null)return;
            Voice chosen=null;for(Voice v:voices){if(v.getLocale().getLanguage().equals("en")&&!v.isNetworkConnectionRequired()){chosen=v;if(v.getLocale().getCountry().equals("GB"))break;}}
            if(chosen!=null){tts.setVoice(chosen);ttsReady=true;}
        });
    }
    private WebResourceResponse denied(){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
    private void callback(String function,Object argument){runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.App && App."+function+"("+JSONObject.quote(String.valueOf(argument))+")",null);});}
    private void toast(String text){runOnUiThread(()->Toast.makeText(this,text,Toast.LENGTH_LONG).show());}
    private String read(InputStream stream,int maximum)throws IOException{try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>maximum)throw new IOException("文件过大");out.write(b,0,n);}return out.toString("UTF-8");}}
    private synchronized String load(){
        int expected=0;
        try(Cursor c=db.rawQuery("SELECT value FROM kv WHERE key='state_count'",null)){if(c.moveToFirst())expected=Integer.parseInt(c.getString(0));}
        if(expected>0){
            if(expected>256)throw new IllegalStateException("学习记录超出大小限制");
            StringBuilder result=new StringBuilder();int found=0;
            try(Cursor c=db.rawQuery("SELECT value FROM kv WHERE key LIKE 'state_chunk_%' ORDER BY key",null)){while(c.moveToNext()){result.append(c.getString(0));found++;}}
            if(found!=expected)throw new IllegalStateException("学习记录不完整");
            return result.toString();
        }
        // Read the initial preview build's format; the next save migrates atomically.
        try(Cursor c=db.rawQuery("SELECT value FROM kv WHERE key='state'",null)){return c.moveToFirst()?c.getString(0):"";}
    }
    private synchronized boolean save(String state){
        if(state==null||state.length()>32000000)return false;
        try{JSONObject s=new JSONObject(state);if(s.getInt("version")!=1||!s.has("cards")||!s.has("reviews"))return false;
            // Keep each row below CursorWindow's per-row limit, even after years of reviews.
            db.beginTransaction();
            try{
                db.execSQL("DELETE FROM kv WHERE key='state' OR key='state_count' OR key LIKE 'state_chunk_%'");
                int count=0;
                for(int start=0;start<state.length();){
                    int end=StateCodec.nextEnd(state,start);
                    ContentValues v=new ContentValues();v.put("key",String.format(Locale.ROOT,"state_chunk_%04d",count));v.put("value",state.substring(start,end));
                    if(db.insertOrThrow("kv",null,v)<0)throw new IOException("保存失败");
                    count++;start=end;
                }
                ContentValues meta=new ContentValues();meta.put("key","state_count");meta.put("value",String.valueOf(count));db.insertOrThrow("kv",null,meta);
                db.setTransactionSuccessful();
            }finally{db.endTransaction();}
            return true;
        }catch(Exception e){return false;}
    }
    private void scanAudio(){
        audio.clear();File base=new File(getFilesDir(),"audio");File[] dirs=base.listFiles();if(dirs==null)return;
        Arrays.sort(dirs,Comparator.comparing(File::getName));
        for(File dir:dirs){if(!dir.isDirectory()||dir.getName().startsWith("."))continue;File[] files=dir.listFiles();if(files!=null)for(File f:files)if(allowedAudio.contains(f.getName()))audio.put(f.getName(),f);}
    }
    private void stop(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}if(tts!=null)tts.stop();}
    private void play(String id,String kind,String text,double rate){
        if(!id.matches("v\\d{5}")||!Arrays.asList("w","s").contains(kind)||text.length()>2000)return;
        String name=id+"_"+kind+".mp3";if(!allowedAudio.contains(name))return;
        stop();
        try{
            File file=audio.get(name);
            if(file==null&&builtIn.contains(name)){
                file=new File(getCacheDir(),name);
                if(!file.exists())try(InputStream in=getAssets().open("audio/"+name);FileOutputStream out=new FileOutputStream(file)){byte[] buf=new byte[16384];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}
            }
            if(file!=null&&file.isFile()){
                player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_MEDIA).build());
                player.setDataSource(file.getAbsolutePath());player.setOnPreparedListener(p->{p.setPlaybackParams(new PlaybackParams().setSpeed((float)Math.max(.8,Math.min(1.2,rate))));p.start();});
                player.setOnCompletionListener(p->{p.release();if(player==p)player=null;});
                player.setOnErrorListener((p,a,b)->{toast("音频播放失败，请重新导入音频包");p.release();if(player==p)player=null;return true;});player.prepareAsync();
            }else if(ttsReady){tts.setSpeechRate((float)rate);tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,name);toast("正在使用系统离线朗读；导入音频包可获得统一发音");}
            else toast("该音频尚未导入。请在「设置 → 导入音频包」选择对应 ZIP 文件。");
        }catch(Exception e){toast("无法播放音频，请重新导入音频包");}
    }
    public class Bridge {
        @JavascriptInterface public String loadState(){try{return load();}catch(Exception e){return "{\"error\":\"无法读取学习记录\"}";}}
        @JavascriptInterface public boolean saveState(String value){return save(value);}
        @JavascriptInterface public void playAudio(String id,String kind,String text,double speed){runOnUiThread(()->play(id,kind,text,speed));}
        @JavascriptInterface public void stopAudio(){runOnUiThread(()->stop());}
        @JavascriptInterface public void exitApp(){runOnUiThread(()->finish());}
        @JavascriptInterface public String audioInfo(){
            try{Set<String> names=new HashSet<>(builtIn);names.addAll(audio.keySet());JSONObject info=new JSONObject();info.put("files",names.size());info.put("expected",allowedAudio.size());info.put("builtin",builtIn.size());info.put("names",new JSONArray(names));info.put("busy",importing);return info.toString();}catch(Exception e){return "{}";}
        }
        @JavascriptInterface public void importAudio(){runOnUiThread(()->{if(importing){toast("音频包正在导入中");return;}choose(101,"application/zip");});}
        @JavascriptInterface public void importBackup(){runOnUiThread(()->choose(102,"application/json"));}
        @JavascriptInterface public void exportBackup(String value){runOnUiThread(()->{if(value.length()>32000000)return;pendingExport=value;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"词屿备份-"+new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(new Date())+".json");try{startActivityForResult(i,103);}catch(Exception e){toast("系统文件选择器不可用");}});}
    }
    private void choose(int code,String mime){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        // Some Android file providers mislabel ZIP / JSON files. Validate content after selection.
        try{startActivityForResult(i,code);}catch(Exception e){toast("无法打开系统文件选择器");}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
        if(request==101){if(importing)return;importing=true;callback("nativeStatus","正在校验并导入音频包，请不要退出应用…");worker.execute(()->importPack(uri));}
        if(request==102)worker.execute(()->{try{String value=read(getContentResolver().openInputStream(uri),32000000);callback("receiveBackup",value);}catch(Exception e){callback("nativeStatus","备份读取失败："+e.getMessage());}});
        if(request==103){String content=pendingExport;pendingExport=null;if(content==null){toast("导出已取消，请重新点击导出备份");return;}worker.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();out.write(content.getBytes(StandardCharsets.UTF_8));callback("nativeStatus","备份已保存。请妥善保留这个 JSON 文件。");}catch(Exception e){callback("nativeStatus","备份保存失败，请重新选择位置。");}});}
    }
    private void deleteTree(File f){if(f.isDirectory()){File[] children=f.listFiles();if(children!=null)for(File c:children)deleteTree(c);}f.delete();}
    private String sha256(File f)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)md.update(b,0,n);}StringBuilder h=new StringBuilder();for(byte v:md.digest())h.append(String.format("%02x",v&255));return h.toString();}
    private void importPack(Uri uri){
        File base=new File(getFilesDir(),"audio");base.mkdirs();File stage=new File(base,".import-"+System.currentTimeMillis());stage.mkdirs();
        try{
            long total=0;int count=0;Set<String> seen=new HashSet<>();
            try(ZipInputStream zip=new ZipInputStream(getContentResolver().openInputStream(uri))){
                ZipEntry e;byte[] buffer=new byte[32768];
                while((e=zip.getNextEntry())!=null){
                    String name=e.getName();if(e.isDirectory())continue;
                    if(!name.equals("manifest.json")&&!name.equals("LICENSES.txt")&&!allowedAudio.contains(name))throw new IOException("音频包包含不支持的文件");
                    if(!seen.add(name)||++count>16002)throw new IOException("音频包文件重复或过多");
                    File dest=new File(stage,name);long bytes=0;
                    try(OutputStream out=new FileOutputStream(dest)){int n;while((n=zip.read(buffer))!=-1){bytes+=n;total+=n;if(bytes>4000000||total>1000000000L)throw new IOException("音频包超过大小限制");out.write(buffer,0,n);}}
                    if(count%200==0)callback("nativeStatus","正在导入音频：已处理 "+count+" 个文件…");
                }
            }
            File mf=new File(stage,"manifest.json");if(!mf.isFile())throw new IOException("缺少音频包清单");
            JSONObject manifest=new JSONObject(read(new FileInputStream(mf),4000000));
            if(!"wordharbor-audio-v1".equals(manifest.optString("format")))throw new IOException("音频包格式不匹配");
            if(!"ecdict-tatoeba-6500-v1".equals(manifest.optString("contentVersion")))throw new IOException("音频包词库版本不匹配");
            String packId=manifest.getString("id");if(!packId.matches("[a-z0-9_-]{1,60}"))throw new IOException("音频包编号无效");
            JSONObject files=manifest.getJSONObject("files");if(files.length()==0)throw new IOException("音频包是空的");
            Set<String> expected=new HashSet<>();Iterator<String> keys=files.keys();
            while(keys.hasNext()){String name=keys.next();if(!allowedAudio.contains(name))throw new IOException("词条不存在");expected.add(name);File f=new File(stage,name);if(!f.isFile()||!sha256(f).equals(files.getString(name)))throw new IOException("音频校验失败，请重新传输压缩包");}
            Set<String> actual=new HashSet<>(seen);actual.remove("manifest.json");actual.remove("LICENSES.txt");if(!actual.equals(expected))throw new IOException("音频包清单与内容不一致");
            // Versioned directories allow an interrupted import to leave existing audio untouched.
            File dest=new File(base,packId+"-"+System.currentTimeMillis());if(!stage.renameTo(dest))throw new IOException("保存音频失败，可能空间不足");
            scanAudio();
            File[] previous=base.listFiles();if(previous!=null)for(File old:previous)if(!old.equals(dest)&&old.getName().startsWith(packId+"-"))deleteTree(old);
            scanAudio();callback("nativeStatus","导入完成："+files.length()+" 条音频，已可离线播放。");callback("audioChanged","");
        }catch(Exception e){deleteTree(stage);callback("nativeStatus","导入失败："+e.getMessage()+"。原有音频保留。");}
        finally{importing=false;}
    }
    private void goBack(){if(web!=null)web.evaluateJavascript("window.App && App.back()",null);else finish();}
    @Override public void onBackPressed(){goBack();}
    @Override protected void onPause(){super.onPause();stop();}
    @Override protected void onDestroy(){stop();if(tts!=null)tts.shutdown();if(web!=null){web.removeJavascriptInterface("Native");web.destroy();web=null;}worker.shutdown();super.onDestroy();}
}
