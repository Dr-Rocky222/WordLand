package cn.wordharbor.app;

/** Bound individual SQLite rows without splitting UTF-16 surrogate pairs. */
public final class StateCodec {
    private StateCodec() {}
    public static int nextEnd(String value,int start){
        if(start<0||start>value.length())throw new IllegalArgumentException("Invalid offset");
        int end=Math.min(value.length(),start+128000);
        if(end<value.length()&&Character.isHighSurrogate(value.charAt(end-1)))end++;
        return end;
    }
}
